﻿//------------------------------------------------------
// 
// Copyright - (c) - 2014 - Mille Boström 
//
// Youtube channel - http://www.speedcoding.net
//------------------------------------------------------
namespace LetsCreateNetworkGame.Server.Util
{
    class LogMessage
    {
        public string Id { get; set; }
        public string Message { get; set; }
    }
}
