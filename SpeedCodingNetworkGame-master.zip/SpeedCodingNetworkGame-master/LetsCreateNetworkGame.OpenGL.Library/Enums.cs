﻿namespace LetsCreateNetworkGame.OpenGL.Library
{
    public enum Direction
    {
        Left,
        Right,
        Up,
        Down
    }
}