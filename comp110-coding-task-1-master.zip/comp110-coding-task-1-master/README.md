# comp110-coding-task-1
A client-server database system to support a mobile game app.
